# MIRVEX AI CALL — Android (Stage 3, simulyatsiya)
Kotlin + Jetpack Compose. Haqiqiy telefoniya yo'q: suhbat simulyatsiya qilinadi.
Ovoz: telefonning o'z TTS dvigateli. APK GitHub Actions orqali yig'iladi.
