package ai.mirvex.call

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun CallsScreen(p: Prefs, store: Store) {
    val lang = p.lang
    val scope = rememberCoroutineScope()
    val fmt = SimpleDateFormat("HH:mm dd.MM", Locale.getDefault())
    val dayStart = System.currentTimeMillis() - 24L * 3600 * 1000
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).statusBarsPadding().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("MIRVEX", color = MxText, fontWeight = FontWeight.Bold, fontSize = 15.sp, letterSpacing = 3.sp)
        Text(L.t(lang, "tab_calls"), color = MxText, fontWeight = FontWeight.Bold, fontSize = 26.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Panel(Modifier.weight(1f)) {
                Text(L.t(lang, "total"), color = MxMuted, fontSize = 13.sp)
                Text("${p.history.size}", color = MxText, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            }
            Panel(Modifier.weight(1f)) {
                Text(L.t(lang, "today"), color = MxMuted, fontSize = 13.sp)
                Text("${p.history.count { it.at >= dayStart }}", color = MxCyan, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            }
        }
        if (p.history.isEmpty()) {
            Text(L.t(lang, "empty"), color = MxMuted, fontSize = 14.sp)
        }
        p.history.forEach { r ->
            Panel {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(r.name.ifBlank { L.t(lang, "no_name") }, color = MxText, fontWeight = FontWeight.Bold)
                    Text(fmt.format(Date(r.at)), color = MxMuted, fontSize = 13.sp)
                }
                Text(r.reason.ifBlank { "-" }, color = MxMuted, fontSize = 14.sp)
            }
        }
        if (p.history.isNotEmpty()) {
            OutBtn(L.t(lang, "clear"), onClick = { scope.launch { store.clearHistory() } })
        }
    }
}
