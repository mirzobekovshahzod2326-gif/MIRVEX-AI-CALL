package ai.mirvex.call

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val MxBg = Color(0xFF0B0D12)
val MxCard = Color(0xFF141824)
val MxBar = Color(0xFF0F1219)
val MxBorder = Color(0xFF232A3A)
val MxText = Color(0xFFF2F4F8)
val MxMuted = Color(0xFF9AA3B2)
val MxViolet = Color(0xFF7C5CFF)
val MxCyan = Color(0xFF22D3EE)
val MxAi = Color(0xFF1B2133)
val MxCaller = Color(0xFF2A2058)

@Composable
fun MirvexTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = MxViolet, background = MxBg, surface = MxCard,
            onBackground = MxText, onSurface = MxText
        ),
        content = content
    )
}

@Composable
fun GButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    val bg = if (enabled) Brush.horizontalGradient(listOf(MxViolet, MxCyan))
    else Brush.horizontalGradient(listOf(MxBorder, MxBorder))
    Box(
        modifier.fillMaxWidth().height(52.dp).clip(RoundedCornerShape(16.dp)).background(bg)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (enabled) MxBg else MxMuted, fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
}

@Composable
fun OutBtn(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    Box(
        modifier.fillMaxWidth().height(52.dp).clip(RoundedCornerShape(16.dp)).background(MxCard)
            .border(1.dp, MxBorder, RoundedCornerShape(16.dp))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (enabled) MxText else MxMuted, fontSize = 16.sp)
    }
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Box(
        Modifier.clip(shape).background(if (selected) MxCaller else Color.Transparent)
            .border(1.dp, if (selected) MxViolet else MxBorder, shape)
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        Text(text, color = if (selected) MxText else MxMuted, fontSize = 13.sp)
    }
}

@Composable
fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Column(
        modifier.fillMaxWidth().clip(shape).background(MxCard).border(1.dp, MxBorder, shape).padding(14.dp),
        content = content
    )
}

@Composable
fun tfColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = MxText, unfocusedTextColor = MxText,
    focusedBorderColor = MxViolet, unfocusedBorderColor = MxBorder,
    cursorColor = MxCyan, focusedLabelColor = MxCyan, unfocusedLabelColor = MxMuted
)
