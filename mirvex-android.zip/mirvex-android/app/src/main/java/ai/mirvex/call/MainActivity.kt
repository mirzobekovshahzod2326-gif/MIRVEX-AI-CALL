package ai.mirvex.call

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier

class MainActivity : ComponentActivity() {
    private lateinit var speaker: Speaker

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        speaker = Speaker(this)
        val store = Store(this)
        setContent { MirvexTheme { MirvexApp(store, speaker) } }
    }

    override fun onDestroy() {
        speaker.shutdown()
        super.onDestroy()
    }
}

class LiveState {
    var session by mutableStateOf<CallSession?>(null)
    val lines = mutableStateListOf<Line>()
    var ended by mutableStateOf(false)
    var joined by mutableStateOf(false)
    var noTts by mutableStateOf(false)
}

@Composable
fun MirvexApp(store: Store, speaker: Speaker) {
    val loaded = store.flow.collectAsState(null)
    val p = loaded.value
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val live = remember { LiveState() }
    Scaffold(
        containerColor = MxBg,
        bottomBar = {
            if (p != null) {
                NavigationBar(containerColor = MxBar) {
                    val items = listOf(
                        Pair("tab_calls", Icons.Default.Home),
                        Pair("tab_live", Icons.Default.Person),
                        Pair("tab_voice", Icons.Default.Settings)
                    )
                    items.forEachIndexed { i, (key, icon) ->
                        NavigationBarItem(
                            selected = tab == i, onClick = { tab = i },
                            icon = { Icon(icon, contentDescription = null) },
                            label = { Text(L.t(p.lang, key)) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MxCyan, selectedTextColor = MxCyan,
                                unselectedIconColor = MxMuted, unselectedTextColor = MxMuted,
                                indicatorColor = MxCaller
                            )
                        )
                    }
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (p != null) when (tab) {
                0 -> CallsScreen(p, store)
                1 -> LiveScreen(p, live, store, speaker)
                else -> VoiceScreen(p, store, speaker)
            }
        }
    }
}
