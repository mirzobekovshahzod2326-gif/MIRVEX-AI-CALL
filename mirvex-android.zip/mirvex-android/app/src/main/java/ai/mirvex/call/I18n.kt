package ai.mirvex.call

/** UI strings. Tajik texts need native-speaker review. */
object L {
    private val m: Map<String, Map<String, String>> = mapOf(
        "uz" to mapOf(
            "tab_calls" to "Qo‘ng‘iroqlar", "tab_live" to "Jonli", "tab_voice" to "Sozlamalar",
            "total" to "Jami", "today" to "Bugun",
            "empty" to "Hali qo‘ng‘iroq yo‘q. “Jonli” bo‘limida simulyatsiyani boshlang.",
            "no_name" to "Ism aytilmadi", "clear" to "Tarixni tozalash",
            "live_title" to "Jonli suhbat",
            "sim_note" to "Simulyatsiya: haqiqiy telefoniya hali ulanmagan. Qo‘ng‘iroqchi javobini o‘zingiz yozasiz.",
            "start" to "Simulyatsiyani boshlash", "reply" to "Qo‘ng‘iroqchi javobi", "send" to "Yuborish",
            "join" to "Suhbatga qo‘shilish", "end" to "Yangi simulyatsiya",
            "joined" to "Siz suhbatga qo‘shildingiz (simulyatsiya).", "done" to "Suhbat tugadi, tarixga saqlandi.",
            "no_tts" to "Bu til uchun telefonda ovoz yo‘q, matn faqat ekranda ko‘rsatiladi.",
            "voice_title" to "Salomlashuv va ovoz", "owner" to "Sizning ismingiz",
            "greeting" to "Salomlashuv", "ask_name" to "Ism so‘rash", "ask_reason" to "Sabab so‘rash",
            "closing" to "Xayrlashuv", "voice" to "Ovoz (telefondagi)", "speed" to "Tezlik",
            "listen" to "Tinglab ko‘rish", "save" to "Saqlash", "saved" to "Saqlandi",
            "no_voices" to "Bu til uchun telefonda alohida ovozlar topilmadi.",
            "privacy" to "AI ekanligi haqidagi ogohlantirish qo‘ng‘iroqchiga har doim aytiladi. Audio yozib olinmaydi."
        ),
        "ru" to mapOf(
            "tab_calls" to "Звонки", "tab_live" to "Эфир", "tab_voice" to "Настройки",
            "total" to "Всего", "today" to "Сегодня",
            "empty" to "Звонков пока нет. Запустите симуляцию в разделе «Эфир».",
            "no_name" to "Имя не названо", "clear" to "Очистить историю",
            "live_title" to "Живой разговор",
            "sim_note" to "Симуляция: реальная телефония ещё не подключена. Ответы звонящего вводите вы.",
            "start" to "Начать симуляцию", "reply" to "Ответ звонящего", "send" to "Отправить",
            "join" to "Подключиться к разговору", "end" to "Новая симуляция",
            "joined" to "Вы подключились к разговору (симуляция).", "done" to "Разговор завершён, сохранён в историю.",
            "no_tts" to "Для этого языка на телефоне нет голоса, текст показывается только на экране.",
            "voice_title" to "Приветствие и голос", "owner" to "Ваше имя",
            "greeting" to "Приветствие", "ask_name" to "Вопрос об имени", "ask_reason" to "Вопрос о причине",
            "closing" to "Прощание", "voice" to "Голос (на телефоне)", "speed" to "Скорость",
            "listen" to "Прослушать", "save" to "Сохранить", "saved" to "Сохранено",
            "no_voices" to "Для этого языка на телефоне не найдено отдельных голосов.",
            "privacy" to "Предупреждение о том, что это ИИ, звучит всегда. Аудио не записывается."
        ),
        "tg" to mapOf(
            "tab_calls" to "Занголҳо", "tab_live" to "Зинда", "tab_voice" to "Танзимот",
            "total" to "Ҷамъ", "today" to "Имрӯз",
            "empty" to "Ҳоло занг нест. Дар бахши «Зинда» симулятсияро оғоз кунед.",
            "no_name" to "Ном гуфта нашуд", "clear" to "Тоза кардани таърих",
            "live_title" to "Сӯҳбати зинда",
            "sim_note" to "Симулятсия: телефонияи воқеӣ ҳоло пайваст нашудааст. Ҷавоби занграсонро худатон менависед.",
            "start" to "Оғози симулятсия", "reply" to "Ҷавоби занграсон", "send" to "Фиристодан",
            "join" to "Ҳамроҳ шудан ба сӯҳбат", "end" to "Симулятсияи нав",
            "joined" to "Шумо ба сӯҳбат ҳамроҳ шудед (симулятсия).", "done" to "Сӯҳбат тамом шуд, дар таърих сабт шуд.",
            "no_tts" to "Барои ин забон дар телефон овоз нест, матн танҳо дар экран нишон дода мешавад.",
            "voice_title" to "Салом ва овоз", "owner" to "Номи шумо",
            "greeting" to "Салом", "ask_name" to "Пурсидани ном", "ask_reason" to "Пурсидани сабаб",
            "closing" to "Хайрухуш", "voice" to "Овоз (дар телефон)", "speed" to "Суръат",
            "listen" to "Шунидан", "save" to "Захира", "saved" to "Захира шуд",
            "no_voices" to "Барои ин забон дар телефон овозҳои алоҳида ёфт нашуд.",
            "privacy" to "Огоҳӣ дар бораи AI будан ҳамеша гуфта мешавад. Садо сабт намешавад."
        )
    )

    fun t(lang: String, key: String): String = m[lang]?.get(key) ?: m.getValue("uz")[key] ?: key
}
