package ai.mirvex.call

/** Port of core/script_engine.py: the AI says EXACTLY the owner's text. */
object Script {
    val langs = listOf("uz", "ru", "tg")
    val editable = listOf("greeting", "ask_name", "ask_reason", "closing")

    // Mandatory AI disclosure. The owner cannot edit or remove it.
    // uz/ru/tg wording must be reviewed by native speakers before release.
    val disclosure = mapOf(
        "uz" to "Men {owner}ning sun'iy intellekt yordamchisiman. Suhbat matn shaklida qayd etiladi, ovoz yozib olinmaydi.",
        "ru" to "Я ИИ-ассистент {owner}. Разговор фиксируется в виде текста, аудио не записывается.",
        "tg" to "Ман ёрдамчии зеҳни сунъии {owner} ҳастам. Сӯҳбат ҳамчун матн сабт мешавад, садо сабт намешавад."
    )
    val defaults = mapOf(
        "uz" to mapOf(
            "greeting" to "Assalomu alaykum.", "ask_name" to "Iltimos, ismingizni ayting.",
            "ask_reason" to "Qo'ng'iroq sababini qisqacha ayting.",
            "closing" to "Rahmat. Ma'lumotingiz egasiga yetkaziladi. Xayr.",
            "handoff" to "Iltimos, kuting, egasi ulanmoqda."
        ),
        "ru" to mapOf(
            "greeting" to "Здравствуйте.", "ask_name" to "Пожалуйста, назовите ваше имя.",
            "ask_reason" to "Коротко скажите, по какому вопросу вы звоните.",
            "closing" to "Спасибо. Ваше сообщение будет передано владельцу. До свидания.",
            "handoff" to "Пожалуйста, подождите, владелец подключается."
        ),
        "tg" to mapOf(
            "greeting" to "Салом алейкум.", "ask_name" to "Лутфан номатонро бигӯед.",
            "ask_reason" to "Сабаби занг задаништонро кӯтоҳ бигӯед.",
            "closing" to "Ташаккур. Маълумоти шумо ба соҳиб расонида мешавад. Хайр.",
            "handoff" to "Лутфан интизор шавед, соҳиб пайваст мешавад."
        )
    )
    val refusal = mapOf(
        "uz" to setOf("yo'q", "yoq", "xohlamayman", "rozi emasman"),
        "ru" to setOf("нет", "не надо", "не согласен", "не хочу"),
        "tg" to setOf("не", "нест", "намехоҳам", "розӣ нестам")
    )

    fun fullGreeting(owner: String, lang: String, greeting: String): String =
        greeting.trim() + " " + disclosure.getValue(lang).replace("{owner}", owner.trim())
}

sealed interface Act {
    data class Say(val text: String) : Act
    data class Hangup(val reason: String) : Act
    data object Join : Act
}

enum class St { NEW, ASK_NAME, ASK_REASON, DONE, HANDOFF, DECLINED }
data class Line(val speaker: String, val text: String)

class CallSession(
    private val owner: String,
    val lang: String,
    private val texts: Map<String, String>,
    val number: String
) {
    var state = St.NEW
        private set
    var name = ""
        private set
    var reason = ""
        private set
    val lines = mutableListOf<Line>()

    private fun t(key: String): String =
        texts[key]?.takeIf { it.isNotBlank() } ?: Script.defaults.getValue(lang).getValue(key)

    private fun say(text: String): Act.Say { lines.add(Line("ai", text)); return Act.Say(text) }

    fun start(): List<Act> {
        state = St.ASK_NAME
        return listOf(say(Script.fullGreeting(owner, lang, t("greeting"))), say(t("ask_name")))
    }

    fun callerSaid(raw: String): List<Act> {
        val text = raw.trim()
        if (text.isEmpty() || state == St.NEW || state == St.DONE ||
            state == St.HANDOFF || state == St.DECLINED) return emptyList()
        lines.add(Line("caller", text))
        val plain = text.lowercase().trim(' ', '.', '!')
        if (state == St.ASK_NAME && plain in Script.refusal.getValue(lang)) {
            state = St.DECLINED
            return listOf(Act.Hangup("caller_declined"))
        }
        if (state == St.ASK_NAME) {
            name = text; state = St.ASK_REASON
            return listOf(say(t("ask_reason")))
        }
        reason = text; state = St.DONE
        return listOf(say(t("closing")), Act.Hangup("completed"))
    }

    fun ownerJoin(): List<Act> {
        if (state == St.DONE || state == St.DECLINED || state == St.NEW) return emptyList()
        state = St.HANDOFF
        return listOf(say(t("handoff")), Act.Join)
    }
}
