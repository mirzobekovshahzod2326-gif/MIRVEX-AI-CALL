package ai.mirvex.call

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/** Uses the phone's built-in Text-to-Speech. Languages the phone lacks are reported, not faked. */
class Speaker(ctx: Context) {
    private var ready = false
    private val tts: TextToSpeech = TextToSpeech(ctx.applicationContext) { ready = it == TextToSpeech.SUCCESS }

    private fun locale(lang: String) = when (lang) {
        "ru" -> Locale("ru", "RU")
        "tg" -> Locale("tg", "TJ")
        else -> Locale("uz", "UZ")
    }

    fun available(lang: String): Boolean =
        ready && tts.isLanguageAvailable(locale(lang)) >= TextToSpeech.LANG_AVAILABLE

    fun voices(lang: String): List<String> {
        if (!ready) return emptyList()
        return try {
            tts.voices?.filter { it.locale.language == locale(lang).language }
                ?.map { it.name }?.sorted()?.take(6) ?: emptyList()
        } catch (e: Exception) { emptyList() }
    }

    /** Returns false if the phone has no voice for this language. */
    fun speak(text: String, lang: String, speed: Float, voice: String): Boolean {
        if (!available(lang)) return false
        tts.setLanguage(locale(lang))
        tts.setSpeechRate(speed)
        if (voice.isNotEmpty()) {
            tts.voices?.firstOrNull { it.name == voice && it.locale.language == locale(lang).language }
                ?.let { tts.setVoice(it) }
        }
        tts.speak(text, TextToSpeech.QUEUE_ADD, null, "m" + System.nanoTime())
        return true
    }

    fun stop() { tts.stop() }
    fun shutdown() { tts.shutdown() }
}
