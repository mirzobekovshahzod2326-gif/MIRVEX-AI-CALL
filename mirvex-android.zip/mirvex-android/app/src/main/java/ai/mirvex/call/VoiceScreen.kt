package ai.mirvex.call

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VoiceScreen(p: Prefs, store: Store, speaker: Speaker) {
    val lang = p.lang
    val scope = rememberCoroutineScope()
    var owner by remember(lang) { mutableStateOf(p.owner) }
    val fields = remember(lang) {
        mutableStateMapOf<String, String>().also { m ->
            Script.editable.forEach { k ->
                m[k] = p.textsFor(lang)[k]?.takeIf { it.isNotBlank() } ?: Script.defaults.getValue(lang).getValue(k)
            }
        }
    }
    var speed by remember(p.speed) { mutableFloatStateOf(p.speed) }
    var msg by remember(lang) { mutableStateOf("") }
    val voices = speaker.voices(lang)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).statusBarsPadding().imePadding().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("MIRVEX", color = MxText, fontWeight = FontWeight.Bold, fontSize = 15.sp, letterSpacing = 3.sp)
        Text(L.t(lang, "voice_title"), color = MxText, fontWeight = FontWeight.Bold, fontSize = 26.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("uz" to "O‘zbek", "ru" to "Русский", "tg" to "Тоҷикӣ").forEach { (code, label) ->
                Chip(label, lang == code) { scope.launch { store.setLang(code) } }
            }
        }
        OutlinedTextField(
            value = owner, onValueChange = { owner = it }, singleLine = true,
            label = { Text(L.t(lang, "owner")) }, colors = tfColors(), modifier = Modifier.fillMaxWidth()
        )
        Script.editable.forEach { k ->
            OutlinedTextField(
                value = fields[k] ?: "", onValueChange = { fields[k] = it },
                label = { Text(L.t(lang, k)) }, colors = tfColors(), modifier = Modifier.fillMaxWidth()
            )
        }
        Panel {
            Text(L.t(lang, "voice"), color = MxMuted, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            if (voices.isEmpty()) {
                Text(L.t(lang, "no_voices"), color = MxMuted, fontSize = 13.sp)
            } else {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    voices.forEach { v ->
                        Chip(v.substringAfterLast("-").ifBlank { v }.take(18), p.voice == v) { scope.launch { store.setVoice(v) } }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Text(L.t(lang, "speed") + ": " + String.format("%.1fx", speed), color = MxMuted, fontSize = 13.sp)
            Slider(
                value = speed, onValueChange = { speed = it },
                onValueChangeFinished = { scope.launch { store.setSpeed(speed) } },
                valueRange = 0.5f..2.0f,
                colors = SliderDefaults.colors(thumbColor = MxCyan, activeTrackColor = MxViolet)
            )
        }
        GButton(L.t(lang, "listen"), onClick = {
            val text = Script.fullGreeting(owner, lang, fields["greeting"] ?: "")
            if (!speaker.speak(text, lang, speed, p.voice)) msg = L.t(lang, "no_tts")
        })
        OutBtn(L.t(lang, "save"), onClick = {
            scope.launch { store.saveTexts(owner.trim().ifBlank { "Aziz" }, lang, fields.toMap()); msg = L.t(lang, "saved") }
        })
        if (msg.isNotEmpty()) Text(msg, color = MxCyan, fontSize = 13.sp)
        Panel { Text(L.t(lang, "privacy"), color = MxMuted, fontSize = 13.sp) }
    }
}
