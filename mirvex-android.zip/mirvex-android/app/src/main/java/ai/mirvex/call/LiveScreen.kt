package ai.mirvex.call

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

@Composable
fun LiveScreen(p: Prefs, live: LiveState, store: Store, speaker: Speaker) {
    val lang = p.lang
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf("") }

    fun handle(acts: List<Act>) {
        val s = live.session ?: return
        live.lines.clear(); live.lines.addAll(s.lines)
        acts.forEach { a ->
            when (a) {
                is Act.Say -> {
                    if (!speaker.speak(a.text, lang, p.speed, p.voice)) { live.noTts = true }
                }
                is Act.Hangup -> {
                    live.ended = true
                    val rec = CallRecord(s.name, s.number, s.reason, System.currentTimeMillis(), lang, s.state.name)
                    scope.launch { store.addCall(rec) }
                }
                Act.Join -> { live.joined = true }
            }
        }
    }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().imePadding().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("MIRVEX", color = MxText, fontWeight = FontWeight.Bold, fontSize = 15.sp, letterSpacing = 3.sp)
        Text(L.t(lang, "live_title"), color = MxText, fontWeight = FontWeight.Bold, fontSize = 26.sp)
        Text(L.t(lang, "sim_note"), color = MxMuted, fontSize = 13.sp)
        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            live.lines.forEach { l ->
                val ai = l.speaker == "ai"
                Box(Modifier.fillMaxWidth(), contentAlignment = if (ai) Alignment.CenterStart else Alignment.CenterEnd) {
                    Text(
                        l.text, color = MxText, fontSize = 14.sp,
                        modifier = Modifier.fillMaxWidth(0.82f).clip(RoundedCornerShape(16.dp))
                            .background(if (ai) MxAi else MxCaller).padding(12.dp)
                    )
                }
            }
            if (live.noTts) Text(L.t(lang, "no_tts"), color = MxMuted, fontSize = 12.sp)
            if (live.joined) Text(L.t(lang, "joined"), color = MxCyan, fontSize = 13.sp)
            if (live.ended) Text(L.t(lang, "done"), color = MxCyan, fontSize = 13.sp)
        }
        val s = live.session
        val active = s != null && !live.ended && !live.joined
        if (s == null || live.ended) {
            GButton(L.t(lang, if (s == null) "start" else "end"), onClick = {
                speaker.stop()
                live.ended = false; live.joined = false; live.noTts = false; live.lines.clear()
                live.session = CallSession(p.owner, lang, p.textsFor(lang), "+998 90 *** ** 67")
                handle(live.session!!.start())
            })
        } else {
            OutlinedTextField(
                value = input, onValueChange = { input = it }, enabled = active,
                label = { Text(L.t(lang, "reply")) }, colors = tfColors(), modifier = Modifier.fillMaxWidth()
            )
            GButton(L.t(lang, "send"), enabled = active && input.isNotBlank(), onClick = {
                val txt = input; input = ""
                handle(s.callerSaid(txt))
            })
            OutBtn(L.t(lang, "join"), enabled = active, onClick = { handle(s.ownerJoin()) })
        }
    }
}
