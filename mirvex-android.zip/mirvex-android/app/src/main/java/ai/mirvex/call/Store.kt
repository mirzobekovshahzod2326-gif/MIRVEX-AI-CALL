package ai.mirvex.call

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.ds by preferencesDataStore("mirvex")

data class CallRecord(
    val name: String, val number: String, val reason: String,
    val at: Long, val lang: String, val state: String
)

data class Prefs(
    val owner: String = "Aziz",
    val lang: String = "uz",
    val speed: Float = 1f,
    val voice: String = "",
    val texts: Map<String, String> = emptyMap(),   // keys "uz_greeting" ...
    val history: List<CallRecord> = emptyList()
) {
    fun textsFor(l: String): Map<String, String> =
        texts.filterKeys { it.startsWith(l + "_") }.mapKeys { it.key.removePrefix(l + "_") }
}

class Store(private val ctx: Context) {
    private val kOwner = stringPreferencesKey("owner")
    private val kLang = stringPreferencesKey("lang")
    private val kSpeed = floatPreferencesKey("speed")
    private val kVoice = stringPreferencesKey("voice")
    private val kHistory = stringPreferencesKey("history")

    val flow: Flow<Prefs> = ctx.ds.data.map { p ->
        val texts = p.asMap().entries
            .filter { it.key.name.startsWith("t_") }
            .associate { it.key.name.removePrefix("t_") to it.value.toString() }
        Prefs(
            owner = p[kOwner] ?: "Aziz", lang = p[kLang] ?: "uz", speed = p[kSpeed] ?: 1f,
            voice = p[kVoice] ?: "", texts = texts, history = parse(p[kHistory])
        )
    }

    suspend fun setLang(v: String) { ctx.ds.edit { it[kLang] = v; it[kVoice] = "" } }
    suspend fun setSpeed(v: Float) { ctx.ds.edit { it[kSpeed] = v } }
    suspend fun setVoice(v: String) { ctx.ds.edit { it[kVoice] = v } }
    suspend fun saveTexts(owner: String, lang: String, values: Map<String, String>) {
        ctx.ds.edit { p ->
            p[kOwner] = owner
            values.forEach { (k, v) -> p[stringPreferencesKey("t_${lang}_$k")] = v }
        }
    }

    suspend fun addCall(r: CallRecord) {
        ctx.ds.edit { p ->
            val arr = JSONArray(p[kHistory] ?: "[]")
            val o = JSONObject().put("n", r.name).put("p", r.number).put("r", r.reason)
                .put("t", r.at).put("l", r.lang).put("s", r.state)
            val out = JSONArray().put(o)
            for (i in 0 until minOf(arr.length(), 49)) out.put(arr.get(i))
            p[kHistory] = out.toString()
        }
    }

    suspend fun clearHistory() { ctx.ds.edit { it[kHistory] = "[]" } }

    private fun parse(s: String?): List<CallRecord> {
        if (s.isNullOrBlank()) return emptyList()
        return try {
            val a = JSONArray(s)
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                CallRecord(o.optString("n"), o.optString("p"), o.optString("r"),
                    o.optLong("t"), o.optString("l"), o.optString("s"))
            }
        } catch (e: Exception) { emptyList() }
    }
}
